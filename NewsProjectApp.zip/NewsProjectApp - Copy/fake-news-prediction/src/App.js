import logo from "./logo.svg";
import "./App.css";
import FakeNewsPrediction from './components/FakeNewsPrediction'

function App() {
  return (
    <div className="App">
      <FakeNewsPrediction/>
    </div>
  );
}

export default App;
